# chainflow公众号封面skill

用于生成「链流 ChainFlow」微信公众号统一封面文案和 Image2 视觉提示词。

## 使用

```text
运行 chainflow公众号封面skill：MCU
```

或直接输入主题词。

## 推荐项目路径

```text
chainflow-content/skills/chainflow-wechat-cover-skill/
```
